    A=imread('beforeHueShifting.jpg');
    [h,w,d]=size(A);
    R=A(:,:,1); %获取红色分量
    G=A(:,:,2); %获取绿色分量
    B=A(:,:,3); %获取蓝色分量
     
    %% 绿蓝交换
    P1=A;
    P1(:,:,3)=G; 
    P1(:,:,2)=B;
    %% 绿红交换
    P2=A;
    P2(:,:,1)=G; 
    P2(:,:,2)=R;
    %% 红蓝交换
    P3=A;
    P3(:,:,3)=R; 
    P3(:,:,1)=B;
    
    %% 展示结果
    figure;
    subplot(221),imshow(A),title('Original');
    subplot(222),imshow(P1),title('Green-Blue');
    subplot(223),imshow(P2),title('Green-Red');
    subplot(224),imshow(P3),title('Red-Blue');
    imwrite(P1,'C:\Users\m\Desktop\hw5_2000013121_马佳媛\Green-Blue.jpg');
    imwrite(P2,'C:\Users\m\Desktop\hw5_2000013121_马佳媛\Green-Red.jpg');
    imwrite(P3,'C:\Users\m\Desktop\hw5_2000013121_马佳媛\Red-Blue.jpg');

