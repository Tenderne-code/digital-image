function [RGB] = hsi2rgb(HSI)
    [height, width, channel] = size(HSI);
    RGB = uint8(zeros(height, width, channel));
	for i = 1:height
		for j = 1:width
			H = double(HSI(i, j, 1)) * pi / 180;
			S = double(HSI(i, j, 2));
			I = double(HSI(i, j, 3));
			if 0 <= H && H < 2*pi/3
				B = I * (1 - S);
				R = I * (1 + S * cos(H) / cos(pi / 3 - H));
				G = 3 * I - (B + R);
			elseif (2*pi/3 <= H && H < 4*pi/3)
				H = H - 2*pi/3;
				R = I * (1 - S);
				G = I * (1 + S * cos(H) / cos(pi / 3 - H));
				B = 3 * I - (R + G);
			elseif (4*pi/3 <= H && H <= 2*pi)
				H = H - 4*pi/3;
				G = I * (1 - S);
				B = I * (1 + S * cos(H) / cos(pi / 3 - H));
				R = 3 * I - (G + B);
			end
			RGB(i, j, 1) = uint8(R);
			RGB(i, j, 2) = uint8(G);
			RGB(i, j, 3) = uint8(B);
		end
	end
end
