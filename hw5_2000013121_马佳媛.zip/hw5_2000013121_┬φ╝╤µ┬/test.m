Img = imread('beforeHueShifting.jpg');
img = rgb2hsi(Img);
new_img1 = chgSat(img,50);
new_img2 = chgSat(img,200);
result1 = hsi2rgb(new_img1);
result2 = hsi2rgb(new_img2);

figure;
subplot(1,3,1);imshow(Img);title('原图像');
subplot(1,3,2);imshow(result1);title('饱和度*0.5后');
subplot(1,3,3);imshow(result2);title('饱和度*2后');
imwrite(result1,'C:\Users\m\Desktop\hw5_2000013121_马佳媛\0.5S.jpg');
imwrite(result2,'C:\Users\m\Desktop\hw5_2000013121_马佳媛\2S.jpg');
