function [IMG] = chgSat(HSI, per)
    [height, width, channel] = size(HSI);
    IMG = zeros(height, width, channel);
	for i = 1:height
		for j = 1:width
			S =  HSI(i, j, 2);
			S = S * double(per) / 100; % ���ϰٷֱ�
            IMG(i, j, 1) = HSI(i, j, 1);
            IMG(i, j, 2) = S;
            IMG(i, j, 3) = HSI(i, j, 3);
		end
	end
end



