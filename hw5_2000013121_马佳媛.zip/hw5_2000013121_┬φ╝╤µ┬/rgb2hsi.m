function [HSI] = rgb2hsi(RGB)
	R = double(RGB(:, :, 1));
	G = double(RGB(:, :, 2));
	B = double(RGB(:, :, 3));
	sum = R + G + B;
    eps = 1e-3;
    H = acos((0.5*(R-G + R-B)) ./ sqrt((R - G).*(R-G) + (R-B).*(G-B) + eps)) / pi * 180;
    H(B>G) = 360 - H(B>G);
    S = 1 - (3 * min(min(R, G), B)) ./ (sum + eps);
	I = sum / 3.0;
	HSI = cat(3, H, S, I);
end
