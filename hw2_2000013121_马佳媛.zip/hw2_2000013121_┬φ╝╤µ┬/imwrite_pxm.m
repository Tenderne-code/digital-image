%% 新的imwrite函数，对ASCII格式的pbm图像和二进制的ppm、pgm三种图像格式分别进行特判
function [ ] = imwrite_pxm( im, ptype, filename)            % 参数分别为原图像矩阵，图像格式，图像名
    
    % 文件头处理
    fid = fopen(filename, 'wb');            
    psize = size(im);                                       % 得到参数
    h = psize(1);
    w = psize(2);
    phead = ['P',num2str(ptype),' ',num2str(w),' ',num2str(h)];
    if ptype == 1                                           % .pbm 
        phead = [phead, char(10)];
    else                                                    % .pgm/.ppm 
        phead = [phead,' ',num2str(255),char(10)];      
    end
    fwrite(fid, phead);
    
    % 依次对三种图像格式进行特判
    if ptype == 5
        for i =1:h
            for j =1:w
                Img(1,(i-1)*w+j) = im(i, j);
            end
        end
        fwrite(fid, Img, 'uint8');                       	% 将新的图像矩阵写入
        fclose(fid);                                        % 关闭文件标识符，结束写入
    elseif ptype == 6
        for i = 1:h
            for j = 1:w
                for k = 1:3
                    Img(((i-1)*w+(j-1))*3+k) = im(i,j,k);   % 建立新的二进制的图像矩阵
                end
            end
        end
        fwrite(fid, Img, 'uint8');                          % 将新的图像矩阵写入
        fclose(fid);                                            % 关闭文件标识符，结束写入
    else 
        align = ceil(w/8)*8-w;            
        for i =1:h
            for j = 1:w
                if im(i,j)>=128
                    ch = 0;
                else 
                    ch = 1;
                end
                fwrite(fid, ch, 'ubit1', 'b'); 
            end
            for j = 1:align
                fwrite(fid, 0, 'ubit1', 'b');   
            end
        end
        fclose(fid);                                            % 关闭文件标识符，结束写入
    end
        %%
       % thresh = graythresh(im);   %自动确定二值化阈值
        %Img1 = im2bw(im,thresh);     % thresh=0.5 表示将灰度在128以下变为黑色，128以上的变为白色
        %imshow(Img1);
        %disp(Img1);
        %fwrite(fid, Img1);
        %disp(fid);
        
end