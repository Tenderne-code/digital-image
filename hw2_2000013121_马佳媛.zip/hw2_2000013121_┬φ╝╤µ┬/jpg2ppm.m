clc;clear;close all
%% 展示信息
num = imfinfo('greens.jpg');
whos

%% 转变格式并保存ppm,pgm,pbm三种图像文件
img = imread('greens.jpg');
imwrite(img,'C:\Users\m\Desktop\hw2_2000013121_马佳媛\greens.ppm');
imwrite(img,'C:\Users\m\Desktop\hw2_2000013121_马佳媛\greens.pgm');
imwrite(img,'C:\Users\m\Desktop\hw2_2000013121_马佳媛\greens.pbm');

%% 使用自己的imread函数读出greens.pxm图像
ppm = imread_pxm('C:\Users\m\Desktop\hw2_2000013121_马佳媛\greens.ppm');
pgm = imread_pxm('C:\Users\m\Desktop\hw2_2000013121_马佳媛\greens.pgm');
pbm = imread_pxm('C:\Users\m\Desktop\hw2_2000013121_马佳媛\greens.pbm');

%% 画图,在画布上同时对比展示greens.pxm图像
figure
subplot(2,2,1);
imshow(img);
title('greens.jpg');
subplot(2,2,2);
imshow(ppm);
title('greens.ppm');
subplot(2,2,3);
imshow(pgm);
title('greens.pgm');
subplot(2,2,4);
imshow(pbm);
title('greens.pbm');

%% 新imread 函数imread_pxm
function [ IMG ] = imread_pxm( filename )   % 函数参数为文件名，返回值为图像坐标

    %对文件头信息位的读取和处理
    fid= fopen(filename, 'rb');    % 文件标识符fid
    p = fread(fid, 1, '*char');     % 吞掉第一个字符p以保证后面直接读取数字
    num = str2num(fgetl(fid));          % 将信息位直接读取为数字
    [mode, m, n] = deal(num(1),num(2),num(3));  % mode为图像格式p1~p6六种，m和n为像素参数
    
    % 检测信息位数量（即是否为pbm格式）
    if (mode ~= 1)&&(mode ~= 4)    % 若不为pbm格式则正常读取最大像素值
        range = num(4);
    else range = 1;  %pbm格式默认最大像素值为1
    end
    
    %依次对图像格式进行特判
    if num(1) <= 3                 % ASCII 格式
        if mode~=3                 % p1/p2格式，pbm/pgm & ASCII 格式
            for i = 1:n
                for j = 1:m
                    num = 0;
                    ch = fread(fid, 1, 'uint8');
                    while (~feof(fid))&&(ch ~= 32)&&(ch ~= 10)      
                        num = num * 10 + ch - 48;       % 依次转化坐标处的数值
                        ch = fread(fid, 1, 'uint8');
                    end
                    if mode == 1                           % pbm 图像
                        IMG(i,j) = logical(1 - num);    % 由于pbm数值区间特殊，对像素值进行归一处理
                    elseif mode == 2                       % pgm 图像
                        IMG(i,j) = uint8(num);      
                    end
                end
            end
        else              % p3 即 ppm & ASCII 格式
            for i = 1:n
                for j = 1:m
                    for k = 1:3
                        num = 0;
                        ch = fread(fid, 1, 'uint8');
                        while (~feof(fid))&&(ch ~= 32)&&(ch ~= 10)      % 在 ASCII 模式下读出图像的数值
                            num = num * 10 + ch - 48;
                            ch = fread(fid, 1, 'uint8');
                        end
                        IMG(i,j,k) = uint8(num);     % 更新图像坐标处的数值
                    end
                end
            end
        end
    % 二进制格式
    else   
        if mode == 4                                % p4 即 pbm & binary 格式
            ch = fread(fid, 1, 'uint8');            
            loc = 8;
            for s = 1:8                             % 每24位代表一个像素，其中每8位分别代表rgb
                bit(s) = mod(ch,2);                 % 用8位数组bit来存储二进制
                ch = fix(ch / 2);                   % 向0取整
            end
            for i = 1:n
                for j = 1:m
                    IMG(i, j) =  logical(1-bit(loc));     % 在进行归一化时要注意黑白的值的定义，0白1黑
                    loc = loc - 1;
                    if loc == 0 
                        ch = fread(fid, 1, 'uint8');
                        loc = 8;
                        for s = 1:8                             
                            bit(s) = mod(ch,2);                 
                            ch = fix(ch / 2);
                        end
                    end
                end
                if i ~= n
                    ch = fread(fid, 1, 'uint8');                % 八字节对齐
                    loc = 8;
                    for s = 1:8                             
                        bit(s) = mod(ch,2);                
                        ch = fix(ch / 2);
                    end
                end
            end
        elseif mode == 5                        % p5 即 pgm & binary 格式
            for i = 1:n
                for j = 1:m
                    ch = fread(fid, 1, 'uint8');
                    IMG(i,j) =  uint8(ch);      
                end
            end
        else             % p6 即 ppm & binary 格式
            for i = 1:n
                for j = 1:m
                    for k = 1:3
                        ch = fread(fid, 1, 'uint8');
                        IMG(i, j, k) = uint8(ch);  
                    end
                end
            end
        end
    end
end


