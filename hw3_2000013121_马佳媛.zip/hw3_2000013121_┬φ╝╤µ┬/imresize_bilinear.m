function [IMG] = imresize_bilinear(img, scale)
    [height, width, channel] = size(img);
    % 既可以按比例缩放 又可以规定height和width
	[size1, size2] = size(scale);
	if size2 == 2
		scale1 = scale(1, 1) / height;
		scale2 = scale(1, 2) / width;
	else
		scale1 = scale;
		scale2 = scale;
	end
    % 计算新的 height width
	new_height = floor(height * scale1);
	new_width = floor(width * scale2);
    % 计算新的 scale
    scale1 = new_height / height;
    scale2 = new_width / width;
    IMG = uint8(zeros(new_height, new_width, channel));
    map_height_floor = uint32(zeros(new_height, 1));
    map_width_floor = uint32(zeros(new_width, 1));
    map_height_ceil = uint32(zeros(new_height, 1));
    map_width_ceil = uint32(zeros(new_width, 1));
    ratio_height = double(zeros(new_height, 1));
    ratio_width = double(zeros(new_width, 1));
    % 计算new_height上每个点回应的原始点
    for i = 1:new_height
        i0 = (i - 1) / scale1 + 1;
        map_height_floor(i) = floor(i0);
        map_height_ceil(i) = ceil(i0);
        if map_height_ceil(i) > height
            map_height_ceil(i) = height;
        end
        ratio_height(i) = i0 - floor(i0);
    end
    % 计算new_width上每个点回应的原始点
    for j = 1:new_width
        j0 = (j - 1) / scale2 + 1;
        map_width_floor(j) = floor(j0);
        map_width_ceil(j) = ceil(j0);
        if map_width_ceil(j) > width
            map_width_ceil(j) = width;
        end
        ratio_width(j) = j0 - floor(j0);
    end
    % 计算新的 IMG
	for i = 1:new_height
		for j = 1:new_width
            a = ratio_height(i);
            b = ratio_width(j);
            for k = 1:channel
                x_m1_n1 = img(map_height_floor(i), map_width_floor(j), k);
                x_m1_n2 = img(map_height_floor(i), map_width_ceil(j), k);
                x_m2_n1 = img(map_height_ceil(i), map_width_floor(j), k);
                x_m2_n2 = img(map_height_ceil(i), map_width_ceil(j), k);
                % bilinear interpolation
                IMG(i, j, k) = (1-a)*(1-b)*x_m1_n1 + (1-a)*b*x_m2_n1 + a*(1-b)*x_m1_n2 + a*b*x_m2_n2;
            end
		end
    end
end



