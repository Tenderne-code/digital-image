clc;clear;close all

%% 通过自定义new_imresize函数得到缩放后的图像文件
img1 = imread('football.jpg');
img2 = imread('kids.tiff');


%% 画图,在画布上同时对比展示插值之后的图像
p1 = imresize_nearest(img1, 0.8);
p2 = imresize_nearest(img2, 2.0);


%% 展示图象
figure
a1 = subplot(2,2,1);imshow(img1);title('football');
a2 = subplot(2,2,2);imshow(img2);title('kids');
a3 = subplot(2,2,3);imshow(p1);title('football(nearest)');
a4 = subplot(2,2,4);imshow(p2);title('kids(nearest)');
xsize = get(a1, 'XLim');
ysize = get(a1, 'YLim');
set(a3, 'XLim',xsize,'YLim',ysize);
x1size = get(a4, 'XLim');
y1size = get(a4, 'YLim');
set(a2, 'XLim',x1size,'YLim',y1size);




 