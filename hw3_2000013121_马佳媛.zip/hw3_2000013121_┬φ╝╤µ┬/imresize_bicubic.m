function [IMG] = imresize_bicubic(img, scale)
    [height, width, channel] = size(img);
    % 既可以按比例缩放 又可以规定height和width
	[size1, size2] = size(scale);
	if size2 == 2
		scale1 = scale(1, 1) / height;
		scale2 = scale(1, 2) / width;
	else
		scale1 = scale;
		scale2 = scale;
	end
    % 计算新的 height width
	new_height = floor(height * scale1);
	new_width = floor(width * scale2);
    % 计算新的 scale
    scale1 = new_height / height;
    scale2 = new_width / width;
    IMG = uint8(zeros(new_height, new_width, channel));
    uu = double(zeros(new_height, 4));
    vv = double(zeros(new_width, 4));
    map_height = uint32(zeros(new_height, 4));
    map_width = uint32(zeros(new_width, 4));
    B = double(zeros(4, 4));
    A = double(zeros(1, 4));
    C = double(zeros(4, 1));
    % 计算new_height上每个点的对应数据
    for i = 1:new_height
        i0 = (i - 1) / scale1 + 1;
        i1 = floor(i0);
        u = i0 - i1;
        uu(i, 1) = 4 - 8*abs(u+1) + 5*abs(u+1)^2 - abs(u+1)^3;
        uu(i, 2) = 1 - 2*abs(u)^2 + abs(u)^3;
        uu(i, 3) = 1 - 2*abs(u-1)^2 + abs(u-1)^3;
        uu(i, 4) = 4 - 8*abs(u-2) + 5*abs(u-2)^2 - abs(u-2)^3;
        for k = i1-1:i1+2
            map_height(i, k - i1 + 2) = max(1, k);
            map_height(i, k - i1 + 2) = min(map_height(i, k - i1 + 2), height);
        end
    end
    % 计算new_width上每个点的对应数据
    for j = 1:new_width
        j0 = (j - 1) / scale2 + 1;
        j1 = floor(j0);
        v = j0 - j1;
        vv(j, 1) = 4 - 8*abs(v+1) + 5*abs(v+1)^2 - abs(v+1)^3;
        vv(j, 2) = 1 - 2*abs(v)^2 + abs(v)^3;
        vv(j, 3) = 1 - 2*abs(v-1)^2 + abs(v-1)^3;
        vv(j, 4) = 4 - 8*abs(v-2) + 5*abs(v-2)^2 - abs(v-2)^3;
        for k = j1-1:j1+2
            map_width(j, k - j1 + 2) = max(1, k);
            map_width(j, k - j1 + 2) = min(map_width(j, k - j1 + 2), width);
        end
    end
    % 计算新的 IMG
	for i = 1:new_height
		for j = 1:new_width
            for k = 1:channel
                % 计算矩阵B
                for i1 = 1:4
                    for j1 = 1:4
                        map_width(j, j1);
                        B(i1, j1) = img(map_height(i, i1), map_width(j, j1), k);
                    end
                end
                for i1 = 1:4
                    A(1, i1) = uu(i, i1);
                end
                for j1 = 1:4
                    C(j1, 1) = vv(j, j1);
                end
                IMG(i, j, k) = A * B * C;
            end
		end
    end
end



