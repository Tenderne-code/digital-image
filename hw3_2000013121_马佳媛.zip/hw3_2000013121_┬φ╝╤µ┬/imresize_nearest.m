function [IMG] = imresize_nearest(img, scale)
    [height, width, channel] = size(img);
    % 获得原图像的相关数值
    % 既可以按比例缩放 又可以规定height和width
	[size1, size2] = size(scale);
	if size2 == 2
		scale1 = scale(1, 1) / height;
		scale2 = scale(1, 2) / width;
    else   % 长宽按相同比例缩放
		scale1 = scale;
		scale2 = scale;
    end
    % 计算新的 height width
	new_height = floor(height * scale1);
	new_width = floor(width * scale2);
    % 计算新的 scale
    scale1 = new_height / height;
    scale2 = new_width / width;
    % 为新的图像矩阵构建框架
    IMG = uint8(zeros(new_height, new_width, channel));
    % 计算新的 IMG
	for i = 1:new_height
		for j = 1:new_width
			i0 = (i - 1) / scale1 + 1;
			j0 = (j - 1) / scale2 + 1;
            % 四舍五入判断最接近的点 
			if i0 - floor(i0) >= 0.5
                i1 = ceil(i0);
                if i1 > height
                    i1 = i1 - 1;
                end
            else
                i1 = floor(i0);
			end
            % 四舍五入判断最接近的点 
			if j0 - floor(j0) >= 0.5
                j1 = ceil(j0);
                if j1 > width
                    j1 = j1 - 1;
                end
            else
                j1 = floor(j0);
            end
            for k = 1:channel
                IMG(i, j, k) = img(i1, j1, k);
            end
		end
    end
end



