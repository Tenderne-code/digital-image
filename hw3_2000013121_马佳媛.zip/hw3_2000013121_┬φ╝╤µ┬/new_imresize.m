clc;clear;close all

%% 通过自定义new_imresize函数得到缩放后的图像文件
img1 = imread('football.jpg');
img2 = imread('kids.tiff');


%% 画图,在画布上同时对比展示三种插值之后的图像
p1 = imresize_nearest(img1, 0.8);
p2 = imresize_nearest(img2, 2.0);
p3 = imresize_bilinear(img1, 1.5);
p4 = imresize_bilinear(img2, 0.3);
p5 = imresize_bicubic(img1, 4.5);
p6 = imresize_bicubic(img2, 0.7);
imwrite(p1,'C:\Users\m\Desktop\hw3_2000013121_马佳媛\new_football(nearest).jpg');
imwrite(p2,'C:\Users\m\Desktop\hw3_2000013121_马佳媛\new_kids(nearest).tiff');
imwrite(p3,'C:\Users\m\Desktop\hw3_2000013121_马佳媛\new_football(bilinear).jpg');
imwrite(p4,'C:\Users\m\Desktop\hw3_2000013121_马佳媛\new_kids(bilinear).tiff');
imwrite(p5,'C:\Users\m\Desktop\hw3_2000013121_马佳媛\new_football(bicubic).jpg');
imwrite(p6,'C:\Users\m\Desktop\hw3_2000013121_马佳媛\new_kids(bicubic).tiff');

%% 展示图象
figure
a1 = subplot(4,2,1);imshow(img1);title('football');
a2 = subplot(4,2,2);imshow(img2);title('kids');
a3 = subplot(4,2,3);imshow(p1);title('football(nearest)');
a4 = subplot(4,2,4);imshow(p2);title('kids(nearest)');
a5 = subplot(4,2,5);imshow(p3);title('football(bilinear)');
a6 = subplot(4,2,6);imshow(p4);title('kids(bilinear)');
a7 = subplot(4,2,7);imshow(p5);title('football(bicubic)');
a8 = subplot(4,2,8);imshow(p6);title('kids(bicubic)');
xsize = get(a7, 'XLim');
ysize = get(a7, 'YLim');
set(a3, 'XLim',xsize,'YLim',ysize);
set(a1, 'XLim',xsize,'YLim',ysize);
set(a5, 'XLim',xsize,'YLim',ysize);
x1size = get(a4, 'XLim');
y1size = get(a4, 'YLim');
set(a8, 'XLim',x1size,'YLim',y1size);
set(a2, 'XLim',x1size,'YLim',y1size);
set(a6, 'XLim',x1size,'YLim',y1size);




 