clc;clear;close all

%% 通过自定义new_imresize函数得到缩放后的图像文件
img1 = imread('football.jpg');
img2 = imread('kids.tiff');


%% 画图,在画布上同时对比展示插值之后的图像
p1 = imresize_bilinear(img1, 1.5);
p2 = imresize_bilinear(img2, 0.3);


%% 展示图象
figure
a1 = subplot(2,2,1);imshow(img1);title('football');
a2 = subplot(2,2,2);imshow(img2);title('kids');
a3 = subplot(2,2,3);imshow(p1);title('football(bilinear)');
a4 = subplot(2,2,4);imshow(p2);title('kids(bilinear)');
xsize = get(a3, 'XLim');
ysize = get(a3, 'YLim');
set(a1, 'XLim',xsize,'YLim',ysize);
x1size = get(a2, 'XLim');
y1size = get(a2, 'YLim');
set(a4, 'XLim',x1size,'YLim',y1size);




 