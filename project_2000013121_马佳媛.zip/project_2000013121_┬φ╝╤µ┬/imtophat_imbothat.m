%% 使用顶帽变换和底帽变换
clc
clear
f=imread('.\images\dipum_images_ch09\Fig0926(a)(rice).tif');
subplot(221),imshow(f);
title('顶帽底帽变换原始图像');
 
se=strel('disk',10);%产生结构元素
%顶帽变换是指原始图像减去其开运算的图像
%而开运算可用于补偿不均匀的背景亮度，所以用一个大的结构元素做开运算后
%然后用原图像减去这个开运算，就得到了背景均衡的图像，这也叫做是图像的顶帽运算
f1=imtophat(f,se);%使用顶帽变换
subplot(222),imshow(f1);
title('使用顶帽变换后的图像');
 
%底帽变换是原始图像减去其闭运算后的图像
f2=imbothat(imcomplement(f),se);%使用底帽变换，为什么原图像要求补呢？
%f2=imbothat(f,se);%使用底帽变换
subplot(223),imshow(f2);
title('使用底帽变换后的图像');
 
%顶帽变换和底帽变换联合起来用，用于增加对比度
f3=imsubtract(imadd(f,imtophat(f,se)),imbothat(f,se));%里面参数好像不合理？
subplot(224),imshow(f3);
title('使用顶帽底帽联合变换后图像');