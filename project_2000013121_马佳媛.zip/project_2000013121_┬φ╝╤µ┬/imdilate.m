
   %% imdilate膨胀
  clc
  clear
 
  A1=imread('.\images\dipum_images_ch09\Fig0906(a)(broken-text).tif');
  info=imfinfo('.\images\dipum_images_ch09\Fig0906(a)(broken-text).tif')
  B=[0 1 0
     1 1 1
     0 1 0];
 A2=imdilate(A1,B);%图像A1被结构元素B膨胀
 A3=imdilate(A2,B);
 A4=imdilate(A3,B);
  
  subplot(221),imshow(A1);
  title('imdilate膨胀原始图像');
  
  subplot(222),imshow(A2);
  title('使用B后1次膨胀后的图像');
  
  subplot(223),imshow(A3);
  title('使用B后2次膨胀后的图像');
 
  subplot(224),imshow(A4);
  title('使用B后3次膨胀后的图像');