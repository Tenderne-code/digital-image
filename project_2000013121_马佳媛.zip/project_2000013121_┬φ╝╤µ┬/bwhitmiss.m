%% bwhitmiss击中或击不中变换
clc
clear
f=imread('.\images\dipum_images_ch09\Fig0913(a)(small-squares).tif');
imshow(f);
title('击中或不击中原始图像');

B1=strel([0 0 0;0 1 1;0 1 0]);%击中：要求击中所有1的位置
B2=strel([1 1 1;1 0 0;1 0 0]);%击不中，要求击不中所有1的位置
B3=strel([0 1 0;1 1 1;0 1 0]);%击中
B4=strel([1 0 1;0 0 0;0 0 0]);%击不中
B5=strel([0 0 0;0 1 0;0 0 0]);%击中
B6=strel([1 1 1;1 0 0;1 0 0]);%击不中

g=imerode(f,B1)&imerode(~f,B2)%利用定义来实现击中或击不中
figure,subplot(221),imshow(g);
title('定义实现组1击中击不中图像');

g1=bwhitmiss(f,B1,B2);
subplot(222),imshow(g1);
title('结构数组1击中击不中后的图像');

g2=bwhitmiss(f,B3,B4);
subplot(223),imshow(g2);
title('结构数组2击中击不中的图像');
 
g3=bwhitmiss(f,B5,B6);
subplot(224),imshow(g3);
title('结构数组3击中击不中的图像');