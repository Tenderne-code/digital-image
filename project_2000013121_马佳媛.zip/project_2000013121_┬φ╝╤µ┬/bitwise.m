    % 10.23: 基于形态学重建的边界清除
    imgGray = cv2.imread("../images/Fig0931a.tif", flags=0)  %flags=0 灰度图像
    ret, imgBinInv = cv2.threshold(imgGray, 205, 255, cv2.THRESH_BINARY_INV)  %二值化处理 (黑色0/白色1)
    imgBin = cv2.bitwise_not(imgBinInv)  % 二值图像的补集 (白色背景)

    %构造标记图像:
    marker = np.zeros_like(imgBin, dtype=np.uint8)
    marker[0, :] = imgBin[0, :]
    marker[-1, :] = imgBin[-1, :]
    marker[:, 0] = imgBin[:, 0]
    marker[:, -1] = imgBin[:, -1]
    markerIni = marker.copy()  % 标记图像: 边框 f(x,y)=I(x,y)，其它为 0

    % 形态学重建
    element = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    while True:
        marker_pre = marker  % 保存 F(n-1)
        dilation = cv2.dilate(marker, kernel=element)  % 膨胀重建
        marker = cv2.bitwise_and(dilation, imgBin)  % 原图像作为模板用来约束重建，按位与，有 0 得 0
        if (marker_pre == marker).all():  % F(n)=F(n-1)?，判断是否达到稳定收敛状态
            break  % 收敛的 marker 就是需要清除的边界字符
    imgRebuild = cv2.bitwise_not(imgBinInv + marker)  % 对收敛的 marker 求补得到边界清除的重建结果

    % 显示
    plt.figure(figsize=(10, 6))
    plt.subplot(221), plt.imshow(imgGray, cmap='gray'), plt.title("origin image"), plt.axis("off")
    plt.subplot(222), plt.imshow(imgBinInv, cmap='gray'), plt.title("mask image"), plt.axis("off")
    plt.subplot(223), plt.imshow(marker, cmap='gray'), plt.title("final marker"), plt.axis("off")
    plt.subplot(224), plt.imshow(imgRebuild, cmap='gray'), plt.title("rebuild image"), plt.axis("off")
    plt.tight_layout()
    plt.show()
