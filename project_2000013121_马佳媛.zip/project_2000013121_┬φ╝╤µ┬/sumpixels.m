%% 颗粒分析
clc
clear
f=imread('.\images\dipum_images_ch09\Fig0925(a)(dowels).tif');

sumpixels=zeros(1,36);
for k=0:35
    se=strel('disk',k);
    fo=imopen(f,se);
    sumpixels(k+1)=sum(fo(:));
end
%可以看到，连续开运算之间的表面积会减少
plot(0:35,sumpixels),xlabel('k'),ylabel('surface area');
title('表面积和结构元素半径之间的关系');

figure,plot(-diff(sumpixels));%diff()函数为差分或者近似倒数，即相邻2个之间的差值
xlabel('k'),ylabel('surface area reduction');
title('减少的表面积和结构元素半径之间的关系');