%% 使用函数bwlabel标注连通分量
 clc
 clear
 f=imread('.\images\dipum_images_ch09\Fig0917(a)(ten-objects).tif');
 imshow(f),title('标注连通分量原始图像');
 
 [L,n]=bwlabel(f);%L为标记矩阵，n为找到连接分量的总数
 [r,c]=find(L==3);%返回第3个对象所有像素的行索引和列索引
 
 rbar=mean(r);
 cbar=mean(c);
 
 figure,imshow(f)
 hold on%保持当前图像使其不被刷新
 for k=1:n
     [r,c]=find(L==k);
     rbar=mean(r);
     cbar=mean(c);
     plot(cbar,rbar,'Marker','o','MarkerEdgeColor','k',...
          'MarkerFaceColor','k','MarkerSize',10);%这个plot函数用法不是很熟悉
     plot(cbar,rbar,'Marker','*','MarkerFaceColor','w');%其中的marker为标记
end
title('标记所有对象质心后的图像');
