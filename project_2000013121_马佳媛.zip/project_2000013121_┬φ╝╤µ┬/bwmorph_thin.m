%% bwmorph组合常见形态学之细化
clc
clear
f=imread('.\images\dipum_images_ch09\Fig0911(a)(noisy-fingerprint).tif');
subplot(221),imshow(f);
title('指纹图像细化原图');

g1=bwmorph(f,'thin',1);
subplot(222),imshow(g1);
title('指纹图像细化原图');
 
g2=bwmorph(f,'thin',2);
subplot(223),imshow(g2);
title('指纹图像细化原图');

g3=bwmorph(f,'thin',Inf);
subplot(224),imshow(g3);
title('指纹图像细化原图');