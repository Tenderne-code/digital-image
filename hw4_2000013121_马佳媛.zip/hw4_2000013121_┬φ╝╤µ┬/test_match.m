close all;
clear all;
clc;

src = imread('office.jpg');
dst = imread('greens.jpg');
hist3 = imhist(dst);
match1 = histeq(src, hist3);
[result, T] = histmatching(src, hist3);
imwrite(result,'C:\Users\m\Desktop\hw4_2000013121_马佳媛\match_result.jpg');
figure;
subplot(4,2,1);imshow(src);title('原图像');
subplot(4,2,3);imshow(dst);title('目标图像');
subplot(4,2,2);imhist(src);title('原图像直方图');
subplot(4,2,4);imhist(dst);title('目标图像直方图');
subplot(4,2,5), imshow(result), title('匹配后得到的图像');
subplot(4,2,6), imhist(result), title('匹配后的直方图');
subplot(4,2,7), imshow(match1), title('histeq得到的图像');
subplot(4,2,8), imhist(match1), title('histeq的直方图');