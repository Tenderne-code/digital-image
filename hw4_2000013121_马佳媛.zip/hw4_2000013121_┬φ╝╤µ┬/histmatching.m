function [image_out, T3] = histmatching(image_in, hist)
% 直方图匹配（规定化）函数
% 输入为需要进行直方图匹配的灰度图像，模板直方图
% 输出为直方图匹配后的灰度图像，进行变换的向量。

% Level为灰度级别
% T1, T2分别为输入图像，模板直方图的均衡化用到的变换向量
% T3为输入图像匹配模板直方图用到的变换向量
Level = 256;
[m, n] = size(image_in);
image_hist = imhist(image_in);
image_out = image_in;
% 求解T1
ac1 = zeros(Level, 1);
T1 = zeros(Level, 1, 'uint8');
ac1(1) = image_hist(1);
for i = 2 : Level
    ac1(i) = ac1(i - 1) + image_hist(i);
end
ac1 = ac1 * (Level - 1);
for i = 1 : 256
    T1(i) = uint8(round((ac1(i)) / (m * n)));
end

% 求解T2
ac2 = zeros(Level, 1);
T2 = zeros(Level, 1, 'uint8');
ac2(1) = hist(1);
for i = 2 : Level
    ac2(i) = ac2(i - 1) + hist(i);
end
ac2 = ac2 * (Level - 1);
hist_sum = sum(hist);
for i = 1 : 256
    T2(i) = uint8(round((ac2(i)) / hist_sum));
end

% 求解T3
% T1映射到T2^(-1)时，若有多个值，选取最小的那个值。
% 产生0 到 255 之间的256个点，即产生0,1,2,...,255的大小为256的数组
temp = zeros(Level, 1, 'uint8');
T3 = T1;
for i = 1 : 256
    for j = 1 : 256
        temp(j) = abs(T1(i) - T2(j));
    end
    [~, B] = min(temp);
    T3(i) = B - 1;
end

% 根据T3转换输入图像的值
for i = 1 : m
    for j = 1 : n
        image_out(i, j) = T3(uint32(image_in(i, j)) + 1);
    end
end
end